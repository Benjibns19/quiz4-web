// Fichier: test.js
fetch('http://localhost:3000/add', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
        name: "anmar",
        email: "anmar@gmail.com"
    })  
})
.then(response => response.text())
.then(data => console.log("Réponse du serveur :", data))
.catch(error => console.error("Erreur :", error));