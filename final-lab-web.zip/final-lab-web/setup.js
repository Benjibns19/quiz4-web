const mysql = require('mysql');

// 1. Connexion au serveur MySQL (sans préciser la database au début)
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'Basket2005!' // <--- METTEZ VOTRE MOT DE PASSE ICI SI VOUS EN AVEZ UN (celui de Workbench)
});

db.connect((err) => {
    if (err) throw err;
    console.log("Connecté à MySQL !");

    // 2. Créer la base de données
    db.query("CREATE DATABASE IF NOT EXISTS my_quiz_db", (err, result) => {
        if (err) throw err;
        console.log("Base de données créée (ou existait déjà).");

        // 3. Sélectionner la base de données
        db.changeUser({database : 'my_quiz_db'}, (err) => {
            if (err) throw err;
            console.log("Base de données sélectionnée.");

            // 4. Créer la table 'users'
            const sql = `CREATE TABLE IF NOT EXISTS users (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(100),
                email VARCHAR(100)
            )`;
            
            db.query(sql, (err, result) => {
                if (err) throw err;
                console.log("Table 'users' créée avec succès !");
                process.exit(); // Arrête le script une fois fini
            });
        });
    });
});