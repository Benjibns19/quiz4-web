const express = require('express');
const mysql = require('mysql');
const app = express();

app.use(express.json()); // Nécessaire pour lire les données (POST/PUT)

// --- 1. CONFIGURATION DE LA CONNEXION ---
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'Basket2005!',  // Votre mot de passe
    database: 'my_quiz_db'    // La base qu'on vient de créer
});

// Connexion à la base
db.connect((err) => {
    if (err) {
        console.error('Erreur de connexion MySQL:', err);
    } else {
        console.log('Connecté à la base de données MySQL !');
    }
});

// --- 2. LES ROUTES (CRUD) ---

// CREATE (POST) : Ajouter un utilisateur
// [cite: 18, 29]
app.post('/add', (req, res) => {
    const { name, email } = req.body;
    const sql = 'INSERT INTO users (name, email) VALUES (?, ?)';
    db.query(sql, [name, email], (err, result) => {
        if (err) return res.status(500).send(err);
        res.send(`Utilisateur ajouté avec l'ID: ${result.insertId}`);
    });
});

// READ (GET) : Voir tous les utilisateurs
// [cite: 21, 30]
app.get('/records', (req, res) => {
    const sql = 'SELECT * FROM users';
    db.query(sql, (err, results) => {
        if (err) return res.status(500).send(err);
        res.json(results);
    });
});

// READ (GET) : Voir un seul utilisateur par son ID
// [cite: 22, 31]
app.get('/record/:id', (req, res) => {
    const sql = 'SELECT * FROM users WHERE id = ?';
    db.query(sql, [req.params.id], (err, result) => {
        if (err) return res.status(500).send(err);
        res.json(result);
    });
});

// UPDATE (PUT) : Modifier un utilisateur
// [cite: 23, 32]
app.put('/update/:id', (req, res) => {
    const { name, email } = req.body;
    const sql = 'UPDATE users SET name = ?, email = ? WHERE id = ?';
    db.query(sql, [name, email, req.params.id], (err, result) => {
        if (err) return res.status(500).send(err);
        res.send('Utilisateur mis à jour avec succès.');
    });
});

// DELETE (DELETE) : Supprimer un utilisateur
// [cite: 24, 32]
app.delete('/delete/:id', (req, res) => {
    const sql = 'DELETE FROM users WHERE id = ?';
    db.query(sql, [req.params.id], (err, result) => {
        if (err) return res.status(500).send(err);
        res.send('Utilisateur supprimé avec succès.');
    });
});

// --- 3. LANCER LE SERVEUR ---
const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Serveur démarré sur http://localhost:${PORT}`);
});